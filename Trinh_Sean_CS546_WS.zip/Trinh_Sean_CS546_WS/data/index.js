// CS 546 - Lab 10
// I pledge my honor that I have abided by the Stevens Honor System.
const users = require("./users");

module.exports = {
	users: users
}
