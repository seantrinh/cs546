// CS 546 - Lab 7
// I pledge my honor that I have abided by the Stevens Honor System.
const express = require("express");
const router = express.Router();
const data = require("../data");
const likeData = data.likes;

module.exports = router;
