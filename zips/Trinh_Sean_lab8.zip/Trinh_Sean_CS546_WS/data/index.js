// Lab 8 - CS 546
// I pledge my honor that I have abided by the Stevens Honor System.
const people = require("./people.js");

module.exports = {
	people: people
};
